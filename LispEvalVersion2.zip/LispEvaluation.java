 
package lisp.tomislavt.ext;

import gnu.expr.ModuleExp;
import com.google.appinventor.components.runtime.*;

import jscheme.JS;
import kawa.standard.Scheme;

import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.YaVersion;

@DesignerComponent(version = YaVersion.LISP_EVAL_COMPONENT_VERSION, description = " Component for modest acces to Kawa eval", category = ComponentCategory.EXTENSION, nonVisible = true, iconName = "images/lambda.png")
@SimpleObject(external = true)
@UsesPermissions(permissionNames = "android.permission.WRITE_EXTERNAL_STORAGE, android.permission.WRITE_SETTINGS,"
    + "android.permission.READ_EXTERNAL_STORAGE")
@UsesLibraries(libraries = "jscheme-7.2.jar," + "abcl.jar," + "abcl-contrib.jar")
public class LispEvaluation extends AndroidNonvisibleComponent {

  public LispEvaluation(ComponentContainer container) {
    super(container.$form());

  }

  @SimpleFunction(description = "JScheme evaluation")
  public String JSchemeEvaluation(String expression) {

    String result = JS.eval(expression).toString();

    return result;
  }
  
  @SimpleFunction(description = "Kawa evaluation")
  public String SimpleKawaEval(String expression) {
    
    Scheme scm = new Scheme();
    //For avoiding the: https://www.sourceware.org/ml/kawa/2012-q1/msg00003.html bug
    ModuleExp.alwaysCompile = false;
    
    Object x = null;
    try {
      x = scm.eval(expression);
    } catch (Throwable e) {
      Log.i("Simple eval for Kawa", "Somehow, no eval is performed: " + e.getMessage());
      e.printStackTrace();
    }

    return x.toString();
  }
  
  @SimpleFunction(description = "Kawa evaluation, but with the whole environment present")
  public String KawaEvaluation (String expression) {
    
   Scheme.registerEnvironment ();
   //For avoiding the: https://www.sourceware.org/ml/kawa/2012-q1/msg00003.html bug
   ModuleExp.alwaysCompile = false;
   
   gnu.mapping.Environment.setCurrent(new Scheme().getEnvironment());
   String result = Scheme.eval(expression, gnu.mapping.Environment.current()).toString();

    return result;
  }
}
